<?php

session_start();
$errors = array('email' => '', 'password' => '');
$email = $password = '';

if (isset($_POST['submit'])) {

    //1- check for empty fields.
    if (empty($_POST['email'])) {
        $errors['email'] = "* this field is empty";
    } else {
        $email = $_POST['email'];
    }

    if (empty($_POST['password'])) {
        $errors['password'] = "* this field is empty";
    } else {
        $password = $_POST['password'];
    }

    //2- check for errors
    if (!array_filter($errors)) {

        if (!($con = mysqli_connect("localhost", "root", "")))
            echo "Could not connect to database";

        if (!mysqli_select_db($con, 'PetCare'))
            echo "Could not open URL database ";

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        $POQuery = " SELECT * FROM petOwner WHERE email = '" . $email . "' AND password = '" . $password . "' ";
        $MQuery = " SELECT * FROM manager WHERE manager_email = '" . $email . "' AND password = '" . $password . "' ";
        $POResult = mysqli_query($con, $POQuery);
        $MResult = mysqli_query($con, $MQuery);
        if (!$POResult || !$MResult) {
            echo ("Error description: " . mysqli_error($con));
        } else {
            if (mysqli_num_rows($POResult) == 1) {
                $_SESSION['email'] = $email;
                header("Location:../html/Home.html");
            } else if (mysqli_num_rows($MResult) == 1){
                $_SESSION['email'] = $email;
                header("Location:../html/home2.html");
            }else{
                echo '<script>window.alert("wrong credintials, try again!")</script>';
            }
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Log In </title>
	<link rel="stylesheet" type="text/css" href="../css/logInstyle.css">
</head>
<body>
	<div class="loginbox">
		<img src="../images/user.png" class="avatar" >
		<h1>log In Here</h1>
		<form method="POST" action="../php/logInPage.php">
			<label>Email</label><span style="color:red"><?php echo $errors['email'] ?></span>
			<input type="text" name="email" placeholder="Enter Email" >
			<label>Password</label><span style="color:red"><?php echo $errors['password'] ?></span>
			<input type="password" name="password" placeholder="Enter Password">
			<input type="submit" name="submit" value="Login">
			<a href="../php/forgetpass.php">Forget Password?</a> <br>
			<a href="../php/reg.php">Don't have acount?</a>
		</form>
	</div>
</body>

</html> 