<?php
session_start();
$errors = array('name' => '', 'description' => '', 'price' => '', 'photo' => '');
$name = $description = $price = $photo = '';
if (isset($_POST['submit'])) {

    //1-check empty fields
    if (empty($_POST['name'])) {
        $errors['name'] = '* this field is empty';
    } else {
        $name = $_POST['name'];
    }

    if (empty($_POST['description'])) {
        $errors['description'] = '* this field is empty';
    } else {
        $description = $_POST['description'];
    }

    if (empty($_POST['price'])) {
        $errors['price'] = '* this field is empty';
    } else {
        $price = $_POST['price'];
    }


    $file_name = $file_size = $file_tmp = $extension = $new_file = '';
    $allowed_file_type = array('jpg', 'jpeg', 'png', 'gif');

    if (isset($_FILES['img']['name'])) {
        $file_name = $_FILES['img']['name'];
        $file_size = $_FILES['img']['size'];
        $file_tmp = $_FILES['img']['tmp_name'];
        $explode = explode('.', $file_name);
        $extension = end($explode);
        $new_file = time() . '.' . $extension;
    } else {
        $errors['photo'] = '* this field is empty';
    }

    if (!array_filter($errors)) {
        if (!($con = mysqli_connect("localhost", "root", "")))
            echo "Could not connect to database";

        if (!mysqli_select_db($con, 'PetCare'))
            echo "Could not open URL database ";

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        $reg = "INSERT INTO service(name, photo, description,price) VALUES( '$name', '$new_file', '$description','$price')";
        if (!mysqli_query($con, $reg)) {
            echo "error :" . mysqli_error($con);
        }else{
            if (move_uploaded_file($file_tmp, '../uploads/' . $new_file)) {
                echo '<script>window.alert("Successfully added a new pet.!")</script>';
                header("Location:../php/services.php");
            }else{
                echo '<script>window.alert("failed uploading file!!")</script>';
            }
        }
    } else {
        echo '<script>window.alert("OPPs! Something  went wrong!")</script>';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Add Service </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>


<body>

    <form method="POST" action="../php/addService.php" class="profileStyle" enctype="multipart/form-data">
        <h1> Add Service </h1>
        <p><label for="img"> Photo :</label></p>
        <p><input type="file" name="img" id="img"></p>
        <p><label>Service name :</label></p><input type="text" name="name" size="20" maxlength="30">
        <p><label>Service description :</label></p><textarea name="description" rows="10" cols="110"></textarea>
        <p><label>Service price :</label></p><input type="text" name="price" size="20" maxlength="30">

        <p><input type="submit" name="submit" value="add service"></p>
    </form>
</body>

</html>