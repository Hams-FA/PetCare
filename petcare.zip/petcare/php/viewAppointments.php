<?php
session_start();
require_once '../php/connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Appointemnts List </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
    <style>
        .profileStyle {
            height: auto !important;
        }

        table {
            width: 100%;
            margin: 0;
        }
    </style>
</head>

<body>
    <div class="profileStyle">
        <?php
        $ses_email = (string) $_SESSION['email'];
        $get_app = mysqli_query($mysqli, "SELECT * FROM appointment");
        if (mysqli_num_rows($get_app) > 0) {
        ?>
            <table border="1">
                <tr>
                    <th>S.l</th>
                    <th>owner email</th>
                    <th>Pet</th>
                    <th>Service</th>
                    <th>Note</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Time</th>
                    <th>Action</th>
                </tr>
                <?php
                $count = 1;
                while ($get_result = mysqli_fetch_array($get_app)) {

                    $app_id = htmlspecialchars(trim($get_result['appoint_id']));
                    $ownerEmail = htmlspecialchars(trim($get_result['ownerEmail']));
                    $pet = htmlspecialchars(trim($get_result['pet']));
                    $service = htmlspecialchars(trim($get_result['service']));
                    $note = htmlspecialchars(trim($get_result['note']));
                    $date = htmlspecialchars(trim($get_result['date']));
                    $time = htmlspecialchars(trim($get_result['time']));
                    $apps = htmlspecialchars(trim($get_result['status']));

                    $current_time = time();
                    $db_time = strtotime(date($date . ' ' . $time));
                    if ($current_time >  $db_time) {
                        $status = 'Passed';
                    } else {
                        $status = 'Upcoming';
                    }

                    if ($status == 'Passed') {
                        echo "<tr>";
                        echo "<td>$count</td>";
                        echo "<td><a href='mailto:$ownerEmail'>$ownerEmail</a></td>";
                        echo "<td>$pet</td>";
                        echo "<td>$service</td>";
                        echo "<td>$note</td>";
                        echo "<td>$date</td>";
                        echo "<td>$status</td>";
                        echo "<td>$time</td>";
                        echo "<td><a href='../php/edit-appoinment.php?app_id=$app_id'>Edit</a> | <a href='../php/managerDeleteAppointment.php?app_id=$app_id'>Delete</a> | <a href='../php/viewReview.php?appoint_id=$app_id'>view review</a> <br> <a href='../php/viewProfile.php?email=$ownerEmail'>pet owner profile</a> | <a href='../php/viewPetProfile.php?email=$ownerEmail&name=$pet'>pet profile</a></td>";
                        echo "</tr>";
                    } else {
                        echo "<tr>";
                        echo "<td>$count</td>";
                        echo "<td><a href='mailto:$ownerEmail'>$ownerEmail</a></td>";
                        echo "<td>$pet</td>";
                        echo "<td>$service</td>";
                        echo "<td>$note</td>";
                        echo "<td>$date</td>";
                        echo "<td>$status<br>($apps)</td>";
                        echo "<td>$time</td>";
                        echo "<td><a href='../php/edit-appoinment.php?app_id=$app_id'>Edit</a> | <a href='../php/managerDeleteAppointment.php?app_id=$app_id'>Delete</a> | <a href='../php/acceptAppointment.php?app_id=$app_id&email=$ownerEmail'>Accept</a> | <a href='../php/rejectAppointments.php?app_id=$app_id&email=$ownerEmail'>Reject</a> <br> <a href='../php/viewProfile.php?email=$ownerEmail'>Pet owner profile</a> | <a href='../php/viewPetProfile.php?email=$ownerEmail&name=$pet'>pet profile</a></td>";
                        echo "</tr>";
                    }
                    $count++;
                }
                echo "</table>";
                ?>

            <?php
        } else {
            echo 'No Available Appointments <br>';
        }
            ?>
            <a href="../html/home2.html">Return to HomePage</a>
    </div>
</body>

</html>