<?php 
session_start();
require_once 'connection.php';

if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
    
    $app_id = (int) $_GET['app_id'];
    $ses_email = (string) $_SESSION['email'];

    $check_app_id = mysqli_query($mysqli, "SELECT appoint_id FROM appointment WHERE appoint_id = '$app_id' AND ownerEmail = '$ses_email' ");

    if(mysqli_num_rows($check_app_id) > 0 ) {
        $delete = mysqli_query($mysqli, "DELETE FROM appointment WHERE appoint_id = '$app_id' AND ownerEmail = '$ses_email' ");
        if($delete) {
            header("location:view.php");
            exit();
        } else {
            echo "error :" . mysqli_error($con);
            header("location:view.php");
            exit();
        }
    }
}
?>