<?php
session_start();
require_once '../php/connection.php';
$get_profile = mysqli_query($mysqli, "SELECT * FROM aboutUs");

if (mysqli_num_rows($get_profile) > 0) {
	$get_result = mysqli_fetch_array($get_profile, MYSQLI_ASSOC);
	$date = $get_result['date'];
	$heading = $get_result['heading'];
	$subheading1 = $get_result['subheading1'];
	$subheading2 = $get_result['subheading2'];
	$photo = $get_result['photo'];
}
?>



<!DOCTYPE html>
<html>

<head>
	<title>About Us</title>
	<link rel="stylesheet" type="text/css" href="../css/aboutusstyle.css">
</head>

<body>
	<section class="section-box">
		<!-- Refrence a youtube tutorial -->
		<div class="main-box">
			<img src="../uploads/<?php echo $photo?>">
			<div class="pargraph">
				<?php
				echo "<h1><span>$heading</span></h1>";
				echo "<h5>$subheading1</h5>";
				echo "<p>$subheading2</p>";
				echo "<p>All rights are reseved to &copy;PetCare</p>";
				echo "<p>Call Us!! <span id='telsp'>011-5611-652</span> We are waiting for you!!! or visit us at <span id='telsp'>Anas bin malek road </span> WE ARE WAITING FOR YOU !!!!!</p>";
				?>
				<button type="button"><a href="mailto:info@petcare.com">Contact Us!!</a></button>


			</div>

		</div>
	</section>
</body>

</html>