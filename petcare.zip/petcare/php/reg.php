<?php

session_start();

$errors = array('firstName' => '', 'lastName' => '', 'gender' => '', 'email' => '', 'phone' => '', 'password' => '');
$firstName = $lastName = $gender = $email = $phone = $password = $photo = '';
//if user clicks on submit
if (isset($_POST['submit'])) {

    //1-check empty fields
    if (empty($_POST['firstName'])) {
        $errors['firstName'] = '* this field is empty';
    } else {
        //don't contain digits
        if (1 === preg_match('~[0-9]~', $_POST['firstName'])) {
            $errors['firstName'] = '* first name must contain only letters';
        } else {
            $firstName = $_POST['firstName'];
        }
    }

    if (empty($_POST['lastName'])) {
        $errors['lastName'] = '* this field is empty';
    } else {
        //dont contain digits
        if (1 === preg_match('~[0-9]~', $_POST['lastName'])) {
            $errors['lastName'] = '* last name must contain only letters ( no numbers )';
        } else {
            $lastName = $_POST['lastName'];
        }
    }

    if (empty($_POST['email'])) {
        $errors['email'] = '* this field is empty';
    } else {
        //valid email format
        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = '* enter valid email address';
        } else {
            $email = $_POST['email'];
        }
    }

    if (empty($_POST['phone'])) {
        $errors['phone'] = '* this field is empty';
    } else {
        //valid format
        if (!is_numeric($_POST['phone'])) {
            $errors['phone'] = '* phone numbers must be only digits';
        } else {
            if (strlen($_POST['phone']) != 10) {
                $errors['phone'] = '* phone numbers must be 10 digits long';
            } else {
                $phone = $_POST['phone'];
            }
        }
    }

    if (empty($_POST['password'])) {
        $errors['password'] = '* this field is empty';
    } else {
        //fulfill the condition 
        //1- contain capital letters
        //2- contain small letters
        //3- contain digits.
        if (!preg_match('@[0-9]@', $_POST['password']) || !preg_match('@[A-Z]@', $_POST['password']) || !preg_match('@[a-z]@', $_POST['password'])) {
            $errors['password'] = "password must contain digits,small and capital letters";
        } else {
            // the condition is fulfilled
            $password = $_POST['password'];
        }
    }


    if (empty(filter_input(INPUT_POST, 'gender'))) {
        $errors['gender'] = '* you must select your gender';
    } else {
        $gender = $_POST['gender'];
    }



    $file_name = $file_size = $file_tmp = $extension = $new_file = '';
    $allowed_file_type = array('jpg', 'jpeg', 'png', 'gif');

    if(isset($_FILES['img']['name'])) {
        $file_name = $_FILES['img']['name'];
        $file_size = $_FILES['img']['size'];
        $file_tmp = $_FILES['img']['tmp_name'];
        $explode = explode('.',$file_name);
        $extension = end($explode);
        $new_file = time() . '.'.$extension;
    }else{
        $new_file = 'default';
    }

    //if there is no errors 
    if (!array_filter($errors)) {
        if (!($con = mysqli_connect("localhost", "root", "")))
            // die("<p>Could not connect to database</p>");
            echo "Could not connect to database";

        if (!mysqli_select_db($con, 'PetCare'))
            // die("<p>Could not open URL database</p>");
            echo "Could not open URL database ";

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        //check if user's email exists:
        $emailQuery = " SELECT email FROM petOwner WHERE email = '" . $email . "' ";
        $phoneQuery = " SELECT phone FROM petOwner WHERE phone = '" . $phone . "' ";
        $emailResult = mysqli_query($con, $emailQuery);
        $phoneResult = mysqli_query($con, $phoneQuery);
        if (!$emailQuery || !$phoneQuery) {
            echo ("Error description: " . mysqli_error($con));
        } else {
            if (mysqli_num_rows($emailResult) == 1)
                echo '<script>window.alert("The pet owner with the entered email already exists, try different email.")</script>';
            elseif (mysqli_num_rows($phoneResult) == 1)
                echo '<script>window.alert("The pet owner with the entered phone already exist, try different phone.")</script>';
            else {
                $reg = "INSERT INTO petOwner (firstName,lastName,phone,email,gender,password,photo) VALUES('" . $firstName . "','" . $lastName . "','" . $phone . "','" . $email . "','" . $gender . "','" . $password . "','" . $new_file . "');";
                if (!mysqli_query($con, $reg)) {
                    echo "error :" . mysqli_error($con);
                } else {
                    if($new_file == 'default'){
                            echo '<script>window.alert("you have registered succesfully!")</script>';
                            $_SESSION['email'] = $email;
                            header("Location:../html/Home.html");
                    } else {
                        if (move_uploaded_file($file_tmp, '../uploads/' . $new_file)) {
                            echo '<script>window.alert("you have registered succesfully!")</script>';
                            $_SESSION['email'] = $email;
                            header("Location:../html/Home.html");
                        } else {
                            echo '<script>window.alert("failed in uploading file, try again!")</script>';
                        }
                    }
                }
            }
        }
    }
}
?>




<!DOCTYPE html>
<html>

<head>
    <title>Registration Page</title>
    <link rel="stylesheet" type="text/css" href="../css/logInstyle.css">
</head>

<body>
    <div class="Registation">
        <h1>New Account</h1>

        <form method="POST" action="../php/reg.php" enctype="multipart/form-data">

            <div class="div-pic">
                <img src="../images/user.png" id="img ">
                <input type="file" name="img" id="file">
                <!-- <input type="file" name="uploadfile" value="" /> -->
                <label for="file" id="uploaded">Choose Photo</label>
            </div>
            <label>Email</label> <span style="color:red"><?php echo $errors['email'] ?></span>

            <input type="text" name="email" placeholder="Enter YourEmail">
            <label>First Name</label> <span style="color:red"><?php echo $errors['firstName'] ?></span>

            <input type="text" name="firstName" placeholder="Enter FirstName">
            <label>Last Name</label> <span style="color:red"><?php echo $errors['lastName'] ?></span>

            <input type="text" name="lastName" placeholder="Enter LastName">
            <label>Phone Number</label> <span style="color:red"><?php echo $errors['phone'] ?></span>

            <input type="text" name="phone" placeholder="Enter PhoneNumber">
            <label>Enter Password</label> <span style="color:red"><?php echo $errors['password'] ?></span>

            <input type="Password" name="password" placeholder="Enter Password">
            <label> Gender</label> <span style="color:red"><?php echo $errors['gender'] ?></span>



            <section class="radio-section">

                <div class="radio-list">

                    <div class="radio-item">
                        <input type="radio" name="gender" id="radio1" value="Female">
                        <label for="radio1">Female</label>
                    </div>
                    <div class="radio-item">
                        <input type="radio" name="gender" id="radio2" value="Male">
                        <label for="radio2">Male</label>
                    </div>
            </section>

            <input type="submit" name="submit" value="Sign Up" id="sign">
        </form>

    </div>
</body>

</html>