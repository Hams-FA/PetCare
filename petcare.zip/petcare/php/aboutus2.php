<?php
session_start();
require_once '../php/connection.php';
$errors = array('heading' => '', 'sub-heading1' => '', 'sub-heading2' => '');
$heading = $subheading1 = $subheading2 = '';

?>

<!DOCTYPE html>
<html>

<head>
	<title>Edit About Us</title>
	<link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>

<body>
	<div class="profileStyle">
		<?php
		$query = mysqli_query($mysqli, "SELECT * FROM aboutUs");
		if (mysqli_num_rows($query) > 0) {
			// Get existing data
			$get_result = mysqli_fetch_array($query);
			$heading = htmlspecialchars(trim($get_result['heading']));
			$subheading1 = htmlspecialchars(trim($get_result['subheading1']));
			$subheading2 = htmlspecialchars(trim($get_result['subheading2']));
			$picture = htmlspecialchars(trim($get_result['photo']));
		} else {
			echo '<script>window.alert("error in fetching data!")</script>';
		}

		if (isset($_POST['submit'])) {

			$heading = $_POST['heading'];
			$subheading1 = $_POST['sub-heading1'];
			$subheading2 = $_POST['sub-heading2'];

			$file_name = $file_size = $file_tmp = $extension = $new_file = '';
			$allowed_file_type = array('jpg', 'jpeg', 'png', 'gif');

			if (isset($_FILES['img']['name'])) {
				$file_name = $_FILES['img']['name'];
				$file_size = $_FILES['img']['size'];
				$file_tmp = $_FILES['img']['tmp_name'];
				$explode = explode('.', $file_name);
				$extension = end($explode);
				$new_file = time() . '.' . $extension;
			} else {
				$new_file = 'default';
			}

			if (!array_filter($errors)) {
				if (!($con = mysqli_connect("localhost", "root", "")))
					echo "Could not connect to database";

				if (!mysqli_select_db($con, 'PetCare'))
					echo "Could not open URL database ";

				if (mysqli_connect_errno()) {
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
					exit();
				}


				$updateQuery = " UPDATE aboutUs SET heading ='$heading', subheading1= '$subheading1', subheading2='$subheading2', photo='$new_file' WHERE id = 1; ";
				$updateResult = mysqli_query($con, $updateQuery);
				if ($updateResult) {
					if (!empty($file_name)) {
						if (!move_uploaded_file($file_tmp, '../uploads/' . $new_file)) {
							echo '<script>window.alert("coudn\'t upload succesfuly!")</script>';
						} else {
							echo '<script>window.alert("updated successfully!")</script>';
							header("Location:../php/aboutus.php");
						}
					}
					header("Location:../php/aboutus.php");
				} else {
					echo ("Error description: " . mysqli_error($con));
				}
			} else {
				echo '<script>window.alert("errors!")</script>';
			}
		}
		?>
		<form method="POST" action="../php/aboutus2.php" class="profileStyle" enctype="multipart/form-data">
			<h1>Edit About us page</h1>
			<p><label for="img"> Photo :</label></p>
			<p><img src="../uploads/<?php echo $picture; ?>" alt="" width="200" height="200" style="border-radius:100px;"></p>
			<p><input type="file" name="img" id="img"></p>
			<p><label>Heading :</label></p><input type="text" name="heading" size="20" maxlength="30" value="<?php echo $heading; ?>">
			<p><label>Sub-Heading1 :</label></p><textarea name="sub-heading1" rows="4" cols="30"><?php echo $subheading1; ?></textarea>
			<p><label>Sub-Heading2 :</label></p><textarea name="sub-heading2" rows="4" cols="30"><?php echo $subheading2; ?></textarea>
			<br>
			<p><input type="submit" name="submit" value="Update"></p>
		</form>
	</div>
</body>

</html>