<?php
session_start();
require_once '../php/connection.php';

$errors = array('rate' => '', 'notes' => '');
$rate = $note = $po_email = '';

$appoint_id = (int) $_GET['appoint_id'];
$sql = "SELECT * FROM review WHERE appoint_id='$appoint_id'";
$getReview = mysqli_query($mysqli, $sql);

if($get_review) {
    // echo '<script>window.alert("appointemnt is accepted!")</script>';
    // header("location:../php/viewAppointments.php");
    // exit();
    while ($get_result = mysqli_fetch_array($get_review)) {
        $rate = htmlspecialchars(trim($get_result['rate']));
        $po_email = htmlspecialchars(trim($get_result['po_email']));
        $note = htmlspecialchars(trim($get_result['notes']));
    }
} else {
    // echo "error :" . mysqli_error($con);
    echo '<script>window.alert("error, try again!")</script>';
    header("location:../php/viewAppointments.php");
    exit();
}

?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Review Page </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>

<body>




    <div class="profileStyle">
        <h1> Review Page</h1>
        <form method="POST" action="../php/reviewPage.php?appoint_id=<?php echo (int) $_GET['appoint_id']; ?>" >
            <p><label>Choose the rating number(*5 is the best*) :<br> <br>
                </label></p>
                <span style="color:red"><?php echo $errors['rate'] ?></span>
            <p><label> 1
                    <input type="radio" value="1" name="rate" <?php if( '1' == $rate ) echo 'checked="checked"'; ?>></label>
                <label> 2
                    <input type="radio" value="2" name="rate" <?php if( '2' == $rate ) echo 'checked="checked"'; ?>>
                </label><label> 3
                    <input type="radio" value="3" name="rate" <?php if( '3' == $rate ) echo 'checked="checked"'; ?>>
                </label><label> 4
                    <input type="radio" value="4" name="rate" <?php if( '4' == $rate ) echo 'checked="checked"'; ?>>
                </label>
                <label> 5
                    <input type="radio" value="4" name="rate" <?php if( '5' == $rate ) echo 'checked="checked"'; ?>>
                </label>
            </p><br>

            <?php echo (int) $_GET['appoint_id'];?>

            <p><label>Write your notes here :  <span style="color:red"><?php echo $errors['notes'] ?></span><br>
                    <textarea name="notes" rows="4" cols="40" class="Scrolling"><?php echo $note ?></textarea>
                </label></p>

        </form>
    </div>


</body>







</html>