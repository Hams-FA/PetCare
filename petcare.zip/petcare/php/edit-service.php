<?php
session_start();
require_once '../php/connection.php';

$errors = array('name' => '', 'description' => '', 'price' => '', 'photo' => '');
$name = $description = $price = $photo = '';

$ser_id = (int) $_GET['ser_id'];
$get_app_list = mysqli_query($mysqli, "SELECT * FROM service WHERE id = '$ser_id' ");
if (mysqli_num_rows($get_app_list) > 0) {

    $get_results = mysqli_fetch_array($get_app_list);
    $name = htmlspecialchars(trim($get_results['name']));
    $description = htmlspecialchars(trim($get_results['description']));
    $price = htmlspecialchars(trim($get_results['price']));
    $photo = htmlspecialchars(trim($get_results['photo']));
}

if (isset($_POST['submit'])) {

    //1-check empty fields
    if (empty($_POST['name'])) {
        $errors['name'] = '* this field is empty';
    } else {
        $name = $_POST['name'];
    }

    if (empty($_POST['description'])) {
        $errors['description'] = '* this field is empty';
    } else {
        $description = $_POST['description'];
    }

    if (empty($_POST['price'])) {
        $errors['price'] = '* this field is empty';
    } else {
        $price = $_POST['price'];
    }


    $file_name = $file_size = $file_tmp = $extension = $new_file = '';
    $allowed_file_type = array('jpg', 'jpeg', 'png', 'gif');

    if (isset($_FILES['img']['name'])) {
        $file_name = $_FILES['img']['name'];
        $file_size = $_FILES['img']['size'];
        $file_tmp = $_FILES['img']['tmp_name'];
        $explode = explode('.', $file_name);
        $extension = end($explode);
        $new_file = time() . '.' . $extension;
    } else {
        $new_file = 'no photo';
    }

    if (!array_filter($errors)) {
        if (!($con = mysqli_connect("localhost", "root", "")))
            echo "Could not connect to database";

        if (!mysqli_select_db($con, 'PetCare'))
            echo "Could not open URL database ";

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        $ser_id = (int) $_GET['ser_id'];
        $name = htmlspecialchars(trim($_POST['name']));
        $description = htmlspecialchars(trim($_POST['description']));
        $price = htmlspecialchars(trim($_POST['price']));

        $reg = "UPDATE service SET name='$name', description='$description', price='$price',photo ='$new_file' WHERE id='$ser_id'";
        if (!mysqli_query($con, $reg)) {
            echo "error :" . mysqli_error($con);
        } else {
            if (strcmp($new_file[9], ".") != 0) {
                if (move_uploaded_file($file_tmp, '../uploads/' . $new_file)) {
                    echo '<script>window.alert("Successfully added a new pet.!")</script>';
                    header("Location:../php/services.php");
                } else {
                    echo '<script>window.alert("coudn\'t upload file!")</script>';
                }
            } else {
                echo '<script>window.alert("Successfully added a new pet.!")</script>';
                header("Location:../php/services.php");
            }
        }
    } else {
        echo '<script>window.alert("OPPs! Something  went wrong!")</script>';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Edit Service </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>


<body>

    <form method="POST" action="edit-service.php?ser_id=<?php echo $ser_id; ?>" class="profileStyle" enctype="multipart/form-data">
        <h1> Edit Service </h1>
        <p><label for="img"> Photo :</label></p>
        <p><input type="file" name="img" id="img" value="default"></p>
        <p><label>Service name :</label></p><input type="text" name="name" size="20" maxlength="30" value="<?php echo $name; ?>">
        <p><label>Service description :</label></p><textarea name="description" rows="10" cols="110"><?php echo $description; ?></textarea>
        <p><label>Service price :</label></p><input type="text" name="price" size="20" maxlength="30" value="<?php echo $price; ?>">

        <p><input type="submit" name="submit" value="update service"></p>
    </form>
</body>

</html>