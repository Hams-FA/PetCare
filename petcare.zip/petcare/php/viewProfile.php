<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        View Profile
    </title>
    <link rel="stylesheet" type="text/css" href="../css/ppstyle.css ">
</head>

<body>
    <div class="profile-box">
        <?php
        session_start();
        require_once '../php/connection.php';

        $ses_email = (string) $_GET['email'];
        $get_profile = mysqli_query($mysqli, "SELECT * FROM petOwner WHERE email = '$ses_email' ");

        if (mysqli_num_rows($get_profile) > 0) {
            $get_result = mysqli_fetch_array($get_profile, MYSQLI_ASSOC);
            $firstName = $get_result['firstName'];
            $lastName = $get_result['lastName'];
            $gender = $get_result['gender'];
            $phone = $get_result['phone'];
            $photo = $get_result['photo'];
        }
        ?>
        <h1>Profile Information </h1>
        <form method="POST" action="../php/viewp.php" enctype="multipart/form-data">
            <div class="div-pic" style="margin-top:100px;">
                <?php
                if (empty($photo)) {
                    $user_photo = '../images/user.png';
                } else {
                    $user_photo = '../uploads/' . $photo;
                }
                ?>
                <img src="<?php echo $user_photo; ?>" style="width: 200px; height: 200px; border-radius: 100px;" name="img">
            </div>
            <p>
                <input type="file" name="img">
            </p>
            <p>Email</p>
            <p class="email">
                <input type="text" disabled value="<?php echo $ses_email; ?>">
            </p>
            </br>

            <p>First Name</p>
            <p class="fname">
                <input type="text" name="fname" value="<?php echo $firstName; ?>">
            </p>
            </br>

            <p>Last Name</p>
            <p class="lname">
                <input type="text" name="lname" value="<?php echo $lastName; ?>">
            </p>
            </br>

            <p>Phone Number</p>
            <p class="PhoneNumber">
                <input type="text" name="phone" value="<?php echo $phone; ?>">
            </p>
            </br>

            <p> Gender</p>
            <p class="gender">
                <input type="radio" value="Female" name="gender" <?php if ('Female' == $gender) echo 'checked="checked"'; ?>>Female <br />
                <input type="radio" value="Male" name="gender" <?php if ('Male' == $gender) echo 'checked="checked"'; ?>>Male
            </p>
            </br>
            <a href="../html/home2.html">Return to HomePage</a>
        </form>
    </div>
</body>

</html>