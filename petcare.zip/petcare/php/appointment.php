<?php
session_start();
require_once 'connection.php';

$errors = array('pet' => '', 'service' => '', 'note' => '', 'date' => '', 'time' => '');
$pet = $service = $note = $date = $time = '';



//if user clicks on submit
if (isset($_POST['submit'])) {

    //1-check empty fields
    if (empty($_POST['pet'])) {
        $errors['firstName'] = '* this field is empty';
        echo 'error in pet';
    } else {
        $pet = $_POST['pet'];
    }

    if (empty($_POST['service'])) {
        $errors['service'] = '* this field is empty';
        echo 'error in s';
    } else {
        $service = $_POST['service'];
    }

    if (empty($_POST['note'])) {
        $errors['note'] = '* this field is empty';
        echo 'error in n';
    } else {
        $note = $_POST['note'];
    }

    if (empty($_POST['date'])) {
        $errors['phone'] = '* this field is empty';
        echo 'error in d';
    } else {
        $date = $_POST['date'];
    }

    if (empty($_POST['time'])) {
        $errors['time'] = '* this field is empty';
        echo 'error in t';
    } else {
        $time = $_POST['time'];
    }

    //if there is no errors
    if (!array_filter($errors)) {
        if (!($con = mysqli_connect("localhost", "root", "")))
            // die("<p>Could not connect to database</p>");
            echo "Could not connect to database";

        if (!mysqli_select_db($con, 'PetCare'))
            // die("<p>Could not open URL database</p>");
            echo "Could not open URL database ";

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        $ses_email = $_SESSION['email'];
        $time = strtotime($time);
        $time = date('h:i', $time);


        $emailQuery = "SELECT ownerEmail FROM appointment WHERE ownerEmail = '$ses_email' AND date = '$date' AND time = '$time' ";


        $emailResult = mysqli_query($mysqli, $emailQuery);
        if (!$emailResult) {
            echo ("Error description: " . mysqli_error($mysqli));
        } else {
            if (mysqli_num_rows($emailResult) > 0) {
                echo '<script>window.alert("The pet owner with the entered appointemnt already booked, try different time.")</script>';
            } else {

                $reg = "INSERT INTO appointment (ownerEmail,pet,service,note,date,time,status) VALUES('" . $_SESSION["email"] . "','" . $pet . "','" . $service . "','" . $note . "','" . $date . "','" . $time . "','pending');";
                if (!mysqli_query($con, $reg)) {
                    echo "error :" . mysqli_error($con);
                } else {
                    echo '<script>window.alert("Success.")</script>';
                    header("Location:../php/view.php");
                }
            }
        }
    }
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Make Appointment </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>

<body>
    <div id="floatRight"> <img src="DogCat.jpeg" alt="Dog and cat" height="600" width="600"> </div>
    <form id="appointform" method="POST" action="appointment.php" class="profileStyle">
        <h1> Make an appointment </h1>
        <div class="Scrolling">
            <label for="pet">Pet: </label><span style="color:red"><?php echo $errors['pet'] ?></span>
            <select name="pet">
                <?php
                $ses_email = (string) $_SESSION['email'];
                $get_app = mysqli_query($mysqli, "SELECT * FROM pet WHERE email='$ses_email' ");
                if (mysqli_num_rows($get_app) > 0) {
                    while ($get_result = mysqli_fetch_array($get_app)) {
                        $name = htmlspecialchars(trim($get_result['name']));
                        echo "<option> $name </option>";
                    }
                }else{
                    echo "<option> you have no pet </option>";
                }
                ?>
            </select>
            <br>
        </div>
        <div class="Scrolling">
            <label> Service :</label><span style="color:red"><?php echo $errors['service'] ?></span>
            <input type="text" name="service" size="30" maxlength="40">
            <br>
        </div>
        <div class="Scrolling">
            <label class="Scrolling"> Note :</label><span style="color:red"><?php echo $errors['note'] ?></span>
            <div><textarea name="note" rows="4" cols="40" placeholder="Write your notes please"></textarea></div>
            <br>
        </div>
        <div class="Scrolling">
            <label class="Scrolling"> Date :</label><span style="color:red"><?php echo $errors['date'] ?></span>
            <input name="date" type="date" id="day">
            <br>
        </div>
        <div class="Scrolling">
            <label class="Scrolling"> Time :</label><span style="color:red"><?php echo $errors['date'] ?></span>
            <input name="time" type="time" id="time">
            <br>
        </div>
        <div><input type="submit" name="submit" value="send request"></div>
    </form>
</body>

</html>