<?php
session_start();
require_once '../php/connection.php';
    
    $app_id = (int) $_GET['app_id'];

        $delete = mysqli_query($mysqli, "DELETE FROM appointment WHERE appoint_id = '$app_id'");
        if($delete) {
            header("location:../php/viewAppointments.php");
            exit();
        } else {
            echo "error :" . mysqli_error($con);
            exit();
        }
?>