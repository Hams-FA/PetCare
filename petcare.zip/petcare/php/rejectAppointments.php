<?php 
session_start();
require_once 'connection.php';

    
    $app_id = (int) $_GET['app_id'];
    $ownerEmail = (string) $_GET['email'];


        $delete = mysqli_query($mysqli, "UPDATE appointment SET status='rejected' WHERE appoint_id = '$app_id' AND ownerEmail = '$ownerEmail' ");
        if($delete) {
            echo '<script>window.alert("appointemnt is accepted!")</script>';
            header("location:../php/viewAppointments.php");
            exit();
        } else {
            echo "error :" . mysqli_error($con);
            echo '<script>window.alert("error, try again!")</script>';
            header("location:../php/viewAppointments.php");
            exit();
        }
?>