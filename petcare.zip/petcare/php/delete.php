<?php 
session_start();
require_once 'connection.php';

if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
    
    $pet_id = (int) $_GET['pet_id'];
    $ses_email = (string) $_SESSION['email'];
    $check_pet_id = mysqli_query($mysqli, "SELECT pet_id FROM pet WHERE pet_id = '$pet_id' AND email = '$ses_email' ");

    if(mysqli_num_rows($check_pet_id) > 0 ) {
        $delete = mysqli_query($mysqli, "DELETE FROM pet WHERE pet_id = '$pet_id' AND email = '$ses_email' ");
        if($delete) {
            header("location:PetList.php");
            exit();
        } else {
            header("location:PetList.php");
            exit();
        }
    }
}
?>