<?php
session_start();
require_once '../php/connection.php';
?>
<!--Edit and delete-->
<!DOCTYPE html>
<html lang="en">

<head>
    <title>View Pet profile</title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>

<body>
    <div class="profileStyle">
        <h1>Profile Information</h1>
        <?php
        $petName = (string) $_GET['name'];
        $ses_email = (string) $_GET['email'];
        $check_pet_id = mysqli_query($mysqli, "SELECT * FROM pet WHERE name = '$petName' AND email = '$ses_email' ");

        if (mysqli_num_rows($check_pet_id) > 0) {
            // Get existing data
            $get_result = mysqli_fetch_array($check_pet_id);
            $name = htmlspecialchars(trim($get_result['name']));
            $email = htmlspecialchars(trim($get_result['email']));
            $birth = htmlspecialchars(trim($get_result['birth']));
            $gender = htmlspecialchars(trim($get_result['gender']));
            $breed = htmlspecialchars(trim($get_result['breed']));
            $spayed_neutered = htmlspecialchars(trim($get_result['spayed_neutered']));
            $vaccinations = htmlspecialchars(trim($get_result['vaccinations']));
            $medicalHistory = htmlspecialchars(trim($get_result['medicalHistory']));
            $pet_picture = htmlspecialchars(trim($get_result['pet_picture']));
        } else {
            echo '<script>window.alert("Sorry, the profile is not found.!")</script>';
        }
        ?>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] . "?pet_id=$pet_id"; ?>" class="profileStyle" enctype="multipart/form-data">
            <h1>Edit your pet details</h1>
            <p><label>Pet name :<input type="text" name="name" size="20" maxlength="30" value="<?php echo $name; ?>"> </label></p>
            <p><label>Date of birth :<input type="date" name="birth" value="<?php echo $birth; ?>"> </label></p>
            <p><label>Gender :<br>

                    <p><label>Female<input type="radio" name="gender" value="Female" <?php if ('Female' == $gender) echo 'checked="checked"'; ?>></label></p>
                    <p><label>Male<input type="radio" name="gender" value="Male" <?php if ('Male' == $gender) echo 'checked="checked"'; ?>></label></p>

                    <p><label>Breed : <input type="text" name="breed" size="40" maxlength="70" value="<?php echo $breed; ?>"> </label></p>
                    <p><label><input type="radio" name="spayed_neutered" value="spayed" <?php if ('spayed' == $spayed_neutered) echo 'checked="checked"'; ?>>spayed </label></p>
                    <p><label><input type="radio" name="spayed_neutered" value="neutered" <?php if ('neutered' == $spayed_neutered) echo 'checked="checked"'; ?>>neutered </label></p>

                    <p><label for="img"> Photo :</label></p>
                    <p><img src="../uploads/<?php echo $pet_picture; ?>" alt="" width="200"></p>
                    <p><input type="file" name="img" id="img"></p>

                    <h3>Optionally fill in the follow : </h3>
                    <p><label>Vaccinations list :<br><textarea name="vaccinations" rows="4" cols="30"><?php echo $vaccinations; ?></textarea></label></p>
                    <p><label>Medical history :<br><textarea name="medicalHistory" rows="4" cols="30"><?php echo $medicalHistory; ?></textarea></label></p>
        </form>
    </div>
</body>

</html>