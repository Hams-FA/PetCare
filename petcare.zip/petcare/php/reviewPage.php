<?php
session_start();
require_once '../php/connection.php';

$errors = array('rate' => '', 'notes' => '');
$rate = $note = '';
//if user clicks on submit
if (isset($_POST['submit'])) {

    //1-check empty fields
    if (empty($_POST['rate'])) {
        $errors['rate'] = '* this field is empty';
    } else {
        $rate = $_POST['rate'];
    }

    if (empty($_POST['notes'])) {
        $errors['notes'] = '* this field is empty';
    } else {
        $note = $_POST['notes'];
    }

    //if there is no errors
    if (!array_filter($errors)) {
        if (!($con = mysqli_connect("localhost", "root", "")))
            echo "Could not connect to database";

        if (!mysqli_select_db($con, 'PetCare'))
            echo "Could not open URL database ";

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        $appoint_id = (int) $_GET['appoint_id'];
        $reg = "INSERT INTO review (appoint_id ,po_email,notes,rate) VALUES('" . $appoint_id . "','" . $_SESSION["email"] . "','" . $note . "','".$rate."');";
        if (!mysqli_query($con, $reg)) {
            echo '<script>window.alert("Error")</script>';
        } else {
            echo '<script>window.alert("Success.")</script>';
            header("Location:../php/view.php");
        }
    }else{
        echo '<script>window.alert("there are Errors")</script>';
    }
}
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Review Page </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>

<body>




    <div class="profileStyle">
        <h1> Review Page</h1>
        <form method="POST" action="../php/reviewPage.php?appoint_id=<?php echo (int) $_GET['appoint_id']; ?>" >
            <p><label>Choose the rating number(*5 is the best*) :<br> <br>
                </label></p>
                <span style="color:red"><?php echo $errors['rate'] ?></span>
            <p><label> 1
                    <input type="radio" value="1" name="rate"></label>
                <label> 2
                    <input type="radio" value="2" name="rate">
                </label><label> 3
                    <input type="radio" value="3" name="rate">
                </label><label> 4
                    <input type="radio" value="4" name="rate">
                </label>
                <label> 5
                    <input type="radio" value="4" name="rate">
                </label>
            </p><br>

            <?php echo (int) $_GET['appoint_id'];?>

            <p><label>Write your notes here :  <span style="color:red"><?php echo $errors['notes'] ?></span><br>
                    <textarea name="notes" rows="4" cols="40" class="Scrolling"></textarea>
                </label></p>

            <p> <input type="submit" value="submit" name="submit" id="sign"></p>


        </form>
    </div>


</body>







</html>