<?php
session_start();
require_once 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Services </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
    <style>
        .profileStyle {
            height: auto !important;
        }

        table {
            width: 100%;
            margin: 0;
        }
    </style>
</head>

<body>
    <div class="profileStyle">
        <?php
        $get_app = mysqli_query($mysqli, "SELECT * FROM service ");
        if (mysqli_num_rows($get_app) > 0) {
        ?>
            <table border="1">
                <tr>
                    <th>S.l</th>
                    <th>photo</th>
                    <th>service name</th>
                    <th>description</th>
                    <th>price</th>
                    <th>Action</th>
                </tr>
                <?php
                $count = 1;
                while ($get_result = mysqli_fetch_array($get_app)) {

                    $ser_id = htmlspecialchars(trim($get_result['id']));
                    $name = htmlspecialchars(trim($get_result['name']));
                    $photo = htmlspecialchars(trim($get_result['photo']));
                    $description = htmlspecialchars(trim($get_result['description']));
                    $price = htmlspecialchars(trim($get_result['price']));

                        echo "<tr>";
                        echo "<td>$count</td>";
                        echo "<td><img src='../uploads/$photo'/ width='50' height = '50'></td>";
                        echo "<td>$name</td>";
                        echo "<td>$description</td>";
                        echo "<td>$price</td>";
                        echo "<td><a href='../php/edit-service.php?ser_id=$ser_id'>Edit</a> | <a href='../php/delete-service.php?ser_id=$ser_id'>Delete</a></td>";
                        echo "</tr>";

                    $count++;
                }
                echo "</table>";
                ?>

            <?php
        } else {
            echo 'No services available <br>';
        }
            ?>

            <a href="../php/addService.php">Add Service</a>
            <br>
            <a href="../html/home2.html">Return to HomePage</a>
    </div>
</body>

</html>