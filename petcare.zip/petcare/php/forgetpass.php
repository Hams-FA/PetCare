<?php

session_start();
$errors = array('email' => '', 'password' => '', 'confirmedPassword' => '');
$email = $password = $confirmedPassword = '';

if (isset($_POST['submit'])) {

	//1- check for empty fields.
	if (empty($_POST['email'])) {
		$errors['email'] = "* this field is empty";
	} else {
		$email = $_POST['email'];
	}

	if (empty($_POST['password'])) {
		$errors['password'] = "* this field is empty";
	} else {
		if (!preg_match('@[0-9]@', $_POST['password']) || !preg_match('@[A-Z]@', $_POST['password']) || !preg_match('@[a-z]@', $_POST['password'])) {
			$errors['password'] = "password must contain digits,small and capital letters";
		} else {
			$password = $_POST['password'];
		}
	}

	if (empty($_POST['confirmedPassword'])) {
		$errors['confirmedPassword'] = "* this field is empty";
	} else {
		$confirmedPassword = $_POST['confirmedPassword'];
	}

	//2- check for errors
	if (!array_filter($errors)) {

		if (!($con = mysqli_connect("localhost", "root", "")))
			echo "Could not connect to database";

		if (!mysqli_select_db($con, 'PetCare'))
			echo "Could not open URL database ";

		if (mysqli_connect_errno()) {
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
			exit();
		}
		$POQuery = " SELECT email FROM petOwner WHERE email = '" . $email . "'";
		$MQuery = " SELECT manager_email FROM manager WHERE manager_email = '" . $email . "'";
		$POResult = mysqli_query($con, $POQuery);
		$MResult = mysqli_query($con, $MQuery);
		if (!$POQuery || !$MQuery) {
			echo ("Error description: " . mysqli_error($con));
		} else {
			if (mysqli_num_rows($POResult) == 1) {
				$POUQuery = " UPDATE petOwner SET password='" . $password . "' WHERE email = '" . $email . "' ";
				$POUQResult = mysqli_query($con, $POUQuery);
				if ($POUQResult) {
					$_SESSION['email'] = $email;
					header("Location:../php/logInPage.php");
				} else {
					echo ("Error description: " . mysqli_error($con));
				}
			} else if (mysqli_num_rows($MResult) == 1){
				$MUQuery = " UPDATE manager SET password='" . $password . "' WHERE manager_email = '" . $email . "' ";
				$MUQResult = mysqli_query($con, $MUQuery);
				if ($MUQResult) {
					$_SESSION['email'] = $email;
					header("Location:../php/logInPage.php");
				} else {
					echo ("Error description: " . mysqli_error($con));
				}
			}else{
				echo '<script>window.alert("wrong credintials, try again!")</script>';
			}
		}
	}
	// else {
	// 	echo '<script>window.alert("feilds can\'t be empty!")</script>';
	// }
}
?>




<!DOCTYPE html>
<html>

<head>
	<title>Forget Password</title>
	<link rel="stylesheet" type="text/css" href="../css/logInstyle.css">
</head>

<body>
	<div class="forgetpass">
		<h1>Reset Password</h1>
		<form method="POST" action="../php/forgetpass.php">
			<label>Email</label><span style="color:red"><?php echo $errors['email'] ?></span>
			<input type="text" name="email" placeholder="Enter YourEmail">

			<label>New Password</label><span style="color:red"><?php echo $errors['password'] ?></span>
			<input type="password" name="password" placeholder="Enter Password">

			<label>Confirm New Password</label><span style="color:red"><?php echo $errors['confirmedPassword'] ?></span>
			<input type="password" name="confirmedPassword" placeholder="Renter Password"><br>

			<input type="submit" name="submit">
			<a href="../html/WelcomePage.html">Return to HomePage</a>
		</form>
	</div>
</body>

</html>