<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        View Profile
    </title>
    <link rel="stylesheet" type="text/css" href="../css/ppstyle.css ">
</head>

<body>
    <div class="profile-box">
        <?php
        session_start();
        require_once '../php/connection.php';

        $ses_email = (string) $_SESSION['email'];
        $get_profile = mysqli_query($mysqli, "SELECT * FROM petOwner WHERE email = '$ses_email' ");

        if (mysqli_num_rows($get_profile) > 0) {
            $get_result = mysqli_fetch_array($get_profile, MYSQLI_ASSOC);
            $firstName = $get_result['firstName'];
            $lastName = $get_result['lastName'];
            $gender = $get_result['gender'];
            $phone = $get_result['phone'];
            $photo = $get_result['photo'];
        }

        if (isset($_POST['submit']) && $_POST['submit'] == 'delete Profile') {
            $delete = mysqli_query($mysqli, "DELETE FROM petOwner WHERE email = '$ses_email'");
            if ($delete) {
                header("location:../html/WelcomePage.html");
                exit();
            } else {
                echo "error :" . mysqli_error($con);
                header("location:../php/view.php");
                exit();
            }
        }

        if (isset($_POST['submit']) && $_POST['submit'] == 'Update Profile') {


            $fname = htmlspecialchars(trim($_POST['fname']));
            $lname = htmlspecialchars(trim($_POST['lname']));
            $phone = htmlspecialchars(trim($_POST['phone']));
            $gender = isset($_POST['gender']) ? htmlspecialchars(trim($_POST['gender'])) : '';

            $file_name = $file_size = $file_tmp = $extension = $new_file = '';
            $allowed_file_type = array('jpg', 'jpeg', 'png', 'gif');

            if (isset($_FILES['img']['name'])) {
                $file_name = $_FILES['img']['name'];
                $file_size = $_FILES['img']['size'];
                $file_tmp = $_FILES['img']['tmp_name'];
                $explode = explode('.', $file_name);
                $extension = end($explode);
                $new_file = time() . '.' . $extension;
            }

            $errors = [];

            if (isset($fname) && isset($lname) && isset($phone) && isset($gender)) {
                if (empty($fname) && empty($lname) && empty($phone) && empty($gender)) {
                    $errors[] = 'All fields is required';
                } else {
                    if (empty($fname)) {
                        $errors[] = 'Firstname is required';
                    } elseif (!preg_match('/^[a-zA-Z. ]+$/', $fname)) {
                        $errors[] = 'Firstname should contain only string characters.';
                    } elseif (strlen($fname) > 50 || strlen($fname) < 2) {
                        $errors[] = 'Firstname length should be less than 5000 characters long.';
                    }

                    if (empty($lname)) {
                        $errors[] = 'Lastname is required';
                    } elseif (!preg_match('/^[a-zA-Z. ]+$/', $lname)) {
                        $errors[] = 'Lastname should contain only string characters.';
                    } elseif (strlen($lname) > 50 || strlen($lname) < 2) {
                        $errors[] = 'Lastname length should be less than 5000 characters long.';
                    }

                    if (empty($phone)) {
                        $errors[] = 'Phone number is required';
                    } elseif (strlen($phone) > 10 || strlen($phone) < 10) {
                        $errors[] = 'Invalid phone number.';
                    }

                    if (empty($gender)) {
                        $errors[] = 'Gender is required';
                    }
                }

                if (!empty($errors)) {
                    echo "<div style='border:1px solid red;padding:10px;background-color:#ffbaba;margin-top:100px;'>";
                    foreach ($errors as $error) {
                        echo "<p style='color:red; margin:0 0 3px 0;padding:0px;'>" . $error . "</p>";
                    }
                    echo "</div>";
                } else {

                    $sql = "UPDATE petOwner ";
                    $sql .= " SET firstName = '$fname', lastName = '$lname', phone = '$phone', gender = '$gender' ";
                    if (!empty($file_name)) {
                        $sql .= " ,photo = '$new_file' ";
                    }

                    $sql .= " WHERE email = '$ses_email'  ";

                    $update = mysqli_query($mysqli, $sql);

                    if ($update) {
                        if (move_uploaded_file($file_tmp, '../uploads/' . $new_file)) {
                            echo '<script>window.alert("Successfully updated your profile.")</script>';
                        }
                    } else {
                        echo '<script>window.alert("OPPs! Something went wrong")</script>';
                        echo mysqli_error($mysqli);
                    }
                }
            }
        }
        ?>
        <h1>Profile Information </h1>
        <form method="POST" action="../php/viewp.php" enctype="multipart/form-data">
            <div class="div-pic" style="margin-top:100px;">
                <?php
                if (empty($photo)) {
                    $user_photo = '../images/user.png';
                } else {
                    $user_photo = '../uploads/' . $photo;
                }
                ?>
                <img src="<?php echo $user_photo; ?>" style="width: 200px; height: 200px; border-radius: 100px;" name="img">
            </div>
            <p>
                <input type="file" name="img">
            </p>
            <p>Email</p>
            <p class="email">
                <input type="text" disabled value="<?php echo $ses_email; ?>">
            </p>
            </br>

            <p>First Name</p>
            <p class="fname">
                <input type="text" name="fname" value="<?php echo $firstName; ?>">
            </p>
            </br>

            <p>Last Name</p>
            <p class="lname">
                <input type="text" name="lname" value="<?php echo $lastName; ?>">
            </p>
            </br>

            <p>Phone Number</p>
            <p class="PhoneNumber">
                <input type="text" name="phone" value="<?php echo $phone; ?>">
            </p>
            </br>

            <p> Gender</p>
            <p class="gender">
                <input type="radio" value="Female" name="gender" <?php if ('Female' == $gender) echo 'checked="checked"'; ?>>Female <br />
                <input type="radio" value="Male" name="gender" <?php if ('Male' == $gender) echo 'checked="checked"'; ?>>Male
            </p>
            </br>
            <input type="submit" name="submit" value="Update Profile">
            <input type="submit" name="submit" value="delete Profile">
            <a href="../html/Home.html">Return to HomePage</a>
        </form>
    </div>
</body>

</html>