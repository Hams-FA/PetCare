<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Add Pet </title>
    <link rel="stylesheet" type="text/css" href="../css/appointPage.css">
</head>


<body>

    <form method="POST" action="../php/addpet.php" class="profileStyle" enctype="multipart/form-data">
        <h1> Add A Pet </h1>
        <?php
        if (isset($_POST['submit']) && $_POST['submit'] == 'add pet') {

            $name = htmlspecialchars(trim($_POST['name']));
            $birth = htmlspecialchars(trim($_POST['birth']));
            $gender = isset($_POST['gender']) ? htmlspecialchars(trim($_POST['gender'])) : '';
            $breed = htmlspecialchars(trim($_POST['breed']));
            $spayed_neutered = isset($_POST['spayed_neutered']) ? htmlspecialchars(trim($_POST['spayed_neutered'])) : '';
            $vaccinations = htmlspecialchars(trim($_POST['vaccinations']));
            $medicalHistory = htmlspecialchars(trim($_POST['medicalHistory']));

            $file_name = $file_size = $file_tmp = $extension = $new_file = '';
            $allowed_file_type = array('jpg', 'jpeg', 'png', 'gif');

            if (isset($_FILES['img']['name'])) {
                $file_name = $_FILES['img']['name'];
                $file_size = $_FILES['img']['size'];
                $file_tmp = $_FILES['img']['tmp_name'];
                $explode = explode('.', $file_name);
                $extension = end($explode);
                $new_file = time() . '.' . $extension;
            }

            $errors = [];

            if (isset($name) && isset($birth) && isset($gender) && isset($breed) && isset($spayed_neutered) && isset($vaccinations) && isset($medicalHistory) && isset($file_name)) {
                if (empty($name) && empty($birth) && empty($gender) && empty($breed) && empty($spayed_neutered) && empty($vaccinations) && empty($medicalHistory) && empty($file_name)) {
                    $errors[] = 'All fields is required';
                } else {
                    if (empty($name)) {
                        $errors[] = 'Name is required';
                    } elseif (!preg_match('/^[a-zA-Z. ]+$/', $name)) {
                        $errors[] = 'Nmae should contain only string characters.';
                    } elseif (strlen($name) > 50 || strlen($name) < 2) {
                        $errors[] = 'Name length should be less than 5000 characters long.';
                    }

                    if (empty($birth)) {
                        $errors[] = 'Birth date is required';
                    }

                    if (empty($gender)) {
                        $errors[] = 'Gender is required';
                    }

                    if (empty($breed)) {
                        $errors[] = 'Breed name is required';
                    } elseif (!preg_match('/^[a-zA-Z. ]+$/', $breed)) {
                        $errors[] = 'Breed name should contain only string characters.';
                    } elseif (strlen($breed) > 50 || strlen($breed) < 2) {
                        $errors[] = 'Breed name length should be less than 5000 characters long.';
                    }

                    if (empty($spayed_neutered)) {
                        $errors[] = 'Breed name is required';
                    }

                    if (empty($file_name)) {
                        $errors[] = 'Upload your pet picture';
                    } elseif (!in_array($extension, $allowed_file_type)) {
                        $errors[] = 'Please upload correct file type, current we are only allowing this file type extension' . implode(',', $allowed_file_type);
                    }

                    if (!empty($vaccinations)) {
                        if (!preg_match('/^[a-zA-Z0-9. ]+$/', $vaccinations)) {
                            $errors[] = 'Vaccinations list should contain only alpha numeric characters.';
                        }
                    }

                    if (!empty($medicalHistory)) {
                        if (!preg_match('/^[a-zA-Z0-9. ]+$/', $medicalHistory)) {
                            $errors[] = 'Medical history list should contain only alpha numeric characters.';
                        }
                    }
                }

                if (!empty($errors)) {
                    echo "<div style='border:1px solid red;padding:10px;background-color:#ffbaba;'>";
                    foreach ($errors as $error) {
                        echo "<p style='color:red; margin:0 0 3px 0;padding:0px;'>" . $error . "</p>";
                    }
                    echo "</div>";
                } else {
                    require_once '../php/connection.php';
                    $email = $_SESSION['email'];

                    $insert = mysqli_query($mysqli, "INSERT INTO pet(email, name, birth, gender, breed, pet_picture, spayed_neutered, vaccinations, medicalHistory) VALUES( '$email', '$name', '$birth', '$gender', '$breed', '$new_file', '$spayed_neutered', '$vaccinations', '$medicalHistory' )");

                    if ($insert) {
                        if (move_uploaded_file($file_tmp, '../uploads/' . $new_file)) {
                            echo '<script>window.alert("Successfully added a new pet.!")</script>';
                            header("Location:../php/PetList.php");
                        }
                    } else {
                        echo '<script>window.alert("OPPs! Something  went wrong!")</script>';
                        echo mysqli_error($mysqli);
                    }
                }
            }
        }
        ?>
        <p><label>Pet name :<input type="text" name="name" size="20" maxlength="30"> </label></p>
        <p><label>Date of birth :<input type="date" name="birth"> </label></p>
        <p><label>Gender :<br>
                <p><label>Female<input type="radio" name="gender" value="Female"></label></p>
                <p><label>Male<input type="radio" name="gender" value="Male"></label></p>
                <p><label>Breed : <input type="text" name="breed" size="40" maxlength="70"> </label></p>
                <p><label><input type="radio" name="spayed_neutered" value="spayed">spayed </label></p>
                <p><label><input type="radio" name="spayed_neutered" value="neutered">neutered </label></p>

                <p><label for="img"> Photo :</label></p>
                <p><input type="file" name="img" id="img"></p>

                <h3>Optionally fill in the follow : </h3>
                <p><label>Vaccinations list :<br><textarea name="vaccinations" rows="4" cols="30"></textarea></label></p>
                <p><label>Medical history :<br><textarea name="medicalHistory" rows="4" cols="30"></textarea></label></p>

                <p><input type="submit" name="submit" value="add pet"></p>
    </form>
</body>

</html>