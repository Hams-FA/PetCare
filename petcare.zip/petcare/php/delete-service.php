<?php 
session_start();
require_once 'connection.php';
    
    $ser_id = (int) $_GET['ser_id'];


        $delete = mysqli_query($mysqli, "DELETE FROM service WHERE id = '$ser_id' ");
        if($delete) {
            header("location:../php/services.php");
            exit();
        } else {
            echo "error :" . mysqli_error($con);
            header("location:../php/services.php");
            exit();
        }
?>