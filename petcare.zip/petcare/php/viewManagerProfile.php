<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        View Profile
    </title>
    <link rel="stylesheet" type="text/css" href="../css/ppstyle.css ">
</head>

<body>
    <div class="profile-box">
        <?php
        session_start();
        require_once '../php/connection.php';

        $ses_email = (string) $_SESSION['email'];
        $get_profile = mysqli_query($mysqli, "SELECT * FROM manager WHERE manager_email = '$ses_email' ");

        if (mysqli_num_rows($get_profile) > 0) {
            $get_result = mysqli_fetch_array($get_profile, MYSQLI_ASSOC);
            $email = $get_result['manager_email'];
            $password = $get_result['password'];
        }
        ?>
        <h1>Profile Information </h1>
        <form method="POST" action="../php/viewManagerProfile.php" enctype="multipart/form-data">
            <p>Email</p>
            <p class="email">
                <input type="text" disabled value="<?php echo $ses_email; ?>">
            </p>
            </br>

            <p>Password</p>
            <p class="email">
                <input type="text"  value="<?php echo $password; ?>">
            </p>
            </br>
            <a href="../html/home2.html">Return to HomePage</a>
        </form>
    </div>
</body>

</html>